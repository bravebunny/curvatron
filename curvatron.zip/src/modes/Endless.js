var Endless = function(game) {

};

Endless.prototype = {

	create: function() {
	},

	update: function() {

	}

};