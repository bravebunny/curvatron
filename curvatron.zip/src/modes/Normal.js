var Normal = function(game) {

};

Normal.prototype = {

	create: function() {
	},

	update: function() {

	}

};